require('dotenv').config()
module.exports = {
    token: process.env.TOKEN,
    guildID: "1033628337031098418",
    welcomeChannel : "1035078296553140234",
    exitChannel: "1035078318007013408",
    ticketParent: "1035081206334767166",
    ticketLogChannel: "1035081316934369351",
    verifyRole : "1035083040323555349"
}